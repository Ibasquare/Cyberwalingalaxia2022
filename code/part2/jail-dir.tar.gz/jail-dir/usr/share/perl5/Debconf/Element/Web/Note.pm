#!/usr/bin/perl -w
# This file was preprocessed, do not edit!


package Debconf::Element::Web::Note;
use strict;
use base qw(Debconf::Element::Web::Text);


1
