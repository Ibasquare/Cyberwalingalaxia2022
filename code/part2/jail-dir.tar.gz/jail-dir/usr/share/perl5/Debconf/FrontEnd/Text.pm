#!/usr/bin/perl -w
# This file was preprocessed, do not edit!


package Debconf::FrontEnd::Text;
use strict;
use base qw(Debconf::FrontEnd::Readline);


1
